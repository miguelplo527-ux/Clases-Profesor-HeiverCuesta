import TokenForm from "./components/TokenForm.jsx";
import DebuggerPanel from "./components/DebuggerPanel.jsx";
import ValidatorPanel from "./components/ValidatorPanel.jsx";
import useToken from "./hooks/useToken.js";
import { TTL_MS } from "./config.js";

export default function App() {
  const { current, history, now, vigente, error, setError, generar } = useToken();

  return (
    <main className="wrap">
      <h1>Formulario</h1>
      <p className="lead">
        Captura un documento y un nombre, genera un token JWT que dura {TTL_MS / 1000} segundos y
        compruébalo: pasado ese tiempo el token deja de ser válido.
      </p>
      <div className="grid">
        <TokenForm
          current={current}
          history={history}
          now={now}
          vigente={vigente}
          error={error}
          setError={setError}
          onGenerar={generar}
        />
        <div className="stack">
          <ValidatorPanel current={current} />
          <DebuggerPanel current={current} />
        </div>
      </div>
      <div className="cuadro-footer">
      <p className="lead"><span className="nombre-grande">Creado Por </span>↴ <br />
                                    <strong>Miguel Angel Segura Velasquez</strong>💰💶</p>
      </div>
    </main>
  );
}
