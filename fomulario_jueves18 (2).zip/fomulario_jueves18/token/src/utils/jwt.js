import { SECRET, TTL_MS } from "../config.js";

const enc = new TextEncoder();
const dec = new TextDecoder();

// ---------- base64url (el formato que usan los JWT) ----------
function b64url(bytes) {
  let s = "";
  for (let i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]);
  return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function fromB64url(str) {
  const b64 = str.replace(/-/g, "+").replace(/_/g, "/");
  const bin = atob(b64 + "=".repeat((4 - (b64.length % 4)) % 4));
  return Uint8Array.from(bin, (c) => c.charCodeAt(0));
}

const b64urlJSON = (obj) => b64url(enc.encode(JSON.stringify(obj)));

const hmacKey = (usages) =>
  crypto.subtle.importKey("raw", enc.encode(SECRET), { name: "HMAC", hash: "SHA-256" }, false, usages);

// ---------- crear el token ----------
export async function signJWT(documento, nombre) {
  const now = Date.now();
  const expiresAt = now + TTL_MS;

  const header = { alg: "HS256", typ: "JWT" };
  // iat y exp van en segundos, con decimales para que el token dure exactamente 4 s
  const payload = { documento, nombre, iat: now / 1000, exp: expiresAt / 1000 };

  const data = `${b64urlJSON(header)}.${b64urlJSON(payload)}`;
  const key = await hmacKey(["sign"]);
  const sig = new Uint8Array(await crypto.subtle.sign("HMAC", key, enc.encode(data)));

  return { token: `${data}.${b64url(sig)}`, header, payload, expiresAt };
}

// ---------- validar el token ----------
// Devuelve { ok, reason, payload?, remainingMs? }
// reason: "formato" | "firma" | "expirado" | "valido"
export async function verifyJWT(token) {
  try {
    const parts = String(token).trim().split(".");
    if (parts.length !== 3) return { ok: false, reason: "formato" };
    const [h, p, s] = parts;

    const header = JSON.parse(dec.decode(fromB64url(h)));
    const payload = JSON.parse(dec.decode(fromB64url(p)));
    // Solo aceptamos HS256 (evita tokens con "alg: none")
    if (header.alg !== "HS256" || typeof payload.exp !== "number") {
      return { ok: false, reason: "formato" };
    }

    // 1) La firma debe coincidir: si alguien cambió el payload, falla aquí
    const key = await hmacKey(["verify"]);
    const firmaOk = await crypto.subtle.verify("HMAC", key, fromB64url(s), enc.encode(`${h}.${p}`));
    if (!firmaOk) return { ok: false, reason: "firma", payload };

    // 2) La fecha de expiración no debe haber pasado
    const remainingMs = payload.exp * 1000 - Date.now();
    if (remainingMs <= 0) return { ok: false, reason: "expirado", payload, remainingMs };

    return { ok: true, reason: "valido", payload, remainingMs };
  } catch {
    return { ok: false, reason: "formato" };
  }
}
