import { useState } from "react";
import { TTL_MS } from "../config.js";

export default function TokenForm({ current, history, now, vigente, error, setError, onGenerar }) {
  const [documento, setDocumento] = useState("");
  const [nombre, setNombre] = useState("");
  const [copied, setCopied] = useState(false);

  const remaining = current ? Math.max(0, current.expiresAt - now) : 0;
  const pct = (remaining / TTL_MS) * 100;
  const parts = current ? current.token.split(".") : [];

  const enviar = () => onGenerar(documento, nombre);
  const limpiarError = () => error && setError("");

  const copiar = async () => {
    try {
      await navigator.clipboard.writeText(current.token);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      /* sin permiso de portapapeles */
    }
  };

  return (
    <section className="card">
      <h2>Crear token</h2>

      <label htmlFor="documento">Documento</label>
      <input
        id="documento"
        type="text"
        inputMode="numeric"
        maxLength={12}
        value={documento}
        className={error && !/^\d{5,12}$/.test(documento.trim()) ? "err" : ""}
        placeholder="Solo números"
        autoComplete="off"
        onChange={(e) => {
          setDocumento(e.target.value.replace(/\D/g, "")); // descarta letras y símbolos
          limpiarError();
        }}
        onKeyDown={(e) => e.key === "Enter" && enviar()}
      />

      <label htmlFor="nombre" style={{ marginTop: 14 }}>Nombre</label>
      <input
        id="nombre"
        type="text"
        value={nombre}
        className={error && !nombre.trim() ? "err" : ""}
        placeholder="Escribe tu nombre"
        autoComplete="off"
        onChange={(e) => {
          setNombre(e.target.value);
          limpiarError();
        }}
        onKeyDown={(e) => e.key === "Enter" && enviar()}
      />
      {error && <p className="error" role="alert">{error}</p>}

      <div className="row">
        <button className="primary" onClick={enviar}>Generar token</button>
      </div>

      {current && (
        <div className="timer">
          <div className="timer-top">
            <span>{vigente ? "Expira en" : "El token expiró"}</span>
            <span className="mono">{(remaining / 1000).toFixed(1)} s</span>
          </div>
          <div
            className={"bar" + (remaining < 1500 ? " low" : "")}
            role="progressbar"
            aria-valuemin={0}
            aria-valuemax={TTL_MS / 1000}
            aria-valuenow={Math.ceil(remaining / 1000)}
          >
            <i style={{ width: `${pct}%` }} />
          </div>
        </div>
      )}

      <div className="small" style={{ marginTop: current ? 14 : 22 }}>
        <strong>Token actual</strong>
        {current && (
          <span className={"badge " + (vigente ? "ok" : "bad")}>{vigente ? "Válido" : "Expirado"}</span>
        )}
      </div>

      {current ? (
        <>
          <div className={"token mono" + (vigente ? "" : " expired")}>
            <span className="h">{parts[0]}</span><span className="d">.</span>
            <span className="p">{parts[1]}</span><span className="d">.</span>
            <span className="s">{parts[2]}</span>
          </div>
          <div className="row">
            <button className="ghost" onClick={copiar}>{copied ? "Copiado" : "Copiar token"}</button>
          </div>
        </>
      ) : (
        <p className="empty" style={{ marginTop: 10 }}>
          Escribe tu documento y tu nombre, y pulsa “Generar token”. El token aparecerá aquí.
        </p>
      )}

      {history.length > 0 && (
        <div className="hist">
          <h2>Tokens anteriores</h2>
          <ul>
            {history.map((tk) => (
              <li key={tk}>
                <span className="t mono">{tk}</span>
                <span className="badge bad">Expirado</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </section>
  );
}
