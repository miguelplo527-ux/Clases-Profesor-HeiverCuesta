import { useState } from "react";
import { verifyJWT } from "../utils/jwt.js";

const MENSAJES = {
  valido: "Token válido",
  expirado: "Token inválido: ya expiró",
  firma: "Token inválido: la firma no coincide (fue modificado)",
  formato: "Token inválido: el formato no es un JWT",
};

export default function ValidatorPanel({ current }) {
  const [texto, setTexto] = useState("");
  const [res, setRes] = useState(null);

  const validar = async () => {
    const r = await verifyJWT(texto);
    setRes({ ...r, hora: new Date().toLocaleTimeString("es-CO") });
  };

  const usarActual = () => {
    if (current) {
      setTexto(current.token);
      setRes(null);
    }
  };

  return (
    <section className="card">
      <h2>Validar token</h2>
      <label htmlFor="tokenTxt">Token a validar</label>
      <textarea
        id="tokenTxt"
        className="mono"
        rows={4}
        value={texto}
        placeholder="Pega un token o usa el actual"
        onChange={(e) => {
          setTexto(e.target.value);
          setRes(null);
        }}
      />
      <div className="row">
        <button className="primary" onClick={validar} disabled={!texto.trim()}>Validar</button>
        <button className="ghost" onClick={usarActual} disabled={!current}>Usar token actual</button>
      </div>

      {res && (
        <div className={"result " + (res.ok ? "ok" : "bad")} role="status">
          <strong>{MENSAJES[res.reason]}</strong>
          <span className="mono">
            {res.ok && ` · le quedan ${(res.remainingMs / 1000).toFixed(1)} s`}
            {res.reason === "expirado" && ` · venció hace ${(-res.remainingMs / 1000).toFixed(1)} s`}
          </span>
          <small>Verificado a las {res.hora}</small>
        </div>
      )}
    </section>
  );
}
