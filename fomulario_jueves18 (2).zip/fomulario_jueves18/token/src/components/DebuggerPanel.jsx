import { SECRET, TTL_MS } from "../config.js";

export default function DebuggerPanel({ current }) {
  return (
    <section className="card dbg">
      <h2>Vista del debugger</h2>
      {current ? (
        <>
          <h3 className="h">Encabezado</h3>
          <pre className="h mono">{JSON.stringify(current.header, null, 2)}</pre>

          <h3 className="p">Carga útil (payload)</h3>
          <pre className="p mono">{JSON.stringify(current.payload, null, 2)}</pre>

          <p className="note">
            El payload lleva el documento, el nombre, la fecha de emisión (<code>iat</code>) y la de
            expiración (<code>exp</code>), que es <code>iat</code> + {TTL_MS / 1000} segundos. Para
            verificar la firma en jwt.io, usa la clave <code>{SECRET}</code> en «your-256-bit-secret».
          </p>
        </>
      ) : (
        <p className="empty">
          Aquí verás el contenido del token: documento, nombre, fecha de emisión (iat) y de
          expiración (exp).
        </p>
      )}
    </section>
  );
}
