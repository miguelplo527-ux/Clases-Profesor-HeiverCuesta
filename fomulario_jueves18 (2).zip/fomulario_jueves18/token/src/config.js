// Duración del token: 4 segundos.
export const TTL_MS = 4000;

// Clave con la que se firma (HS256) y se verifica el token.
// OJO: al estar en el frontend, cualquiera puede verla en el navegador.
// Sirve para esta demo; en un sistema real la firma se hace en un backend.
export const SECRET = "clave-secreta-demo-4s";
