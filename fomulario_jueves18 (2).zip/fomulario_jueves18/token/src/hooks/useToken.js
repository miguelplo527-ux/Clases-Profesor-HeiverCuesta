import { useCallback, useEffect, useState } from "react";
import { signJWT } from "../utils/jwt.js";

export default function useToken() {
  const [current, setCurrent] = useState(null); // último token generado
  const [history, setHistory] = useState([]); // tokens anteriores
  const [now, setNow] = useState(Date.now());
  const [error, setError] = useState("");

  const generar = useCallback(
    async (documento, nombre) => {
      const d = documento.trim();
      const n = nombre.trim();

      if (!/^\d{5,12}$/.test(d)) {
        setError("El documento debe tener solo números (entre 5 y 12 dígitos).");
        return false;
      }
      if (!n) {
        setError("Escribe tu nombre para generar el token.");
        return false;
      }

      setError("");
      try {
        const next = await signJWT(d, n);
        if (current) setHistory((hs) => [current.token, ...hs].slice(0, 5));
        setNow(Date.now());
        setCurrent(next);
        return true;
      } catch {
        setError("No se pudo generar el token en este navegador.");
        return false;
      }
    },
    [current]
  );

  // Reloj: actualiza "now" cada 100 ms mientras el token esté vigente.
  // Al llegar a los 4 s se detiene: el token queda expirado y NO se regenera.
  useEffect(() => {
    if (!current) return;
    const id = setInterval(() => {
      const t = Date.now();
      setNow(t);
      if (t >= current.expiresAt) clearInterval(id);
    }, 100);
    return () => clearInterval(id);
  }, [current]);

  const vigente = !!current && now < current.expiresAt;

  return { current, history, now, vigente, error, setError, generar };
}
